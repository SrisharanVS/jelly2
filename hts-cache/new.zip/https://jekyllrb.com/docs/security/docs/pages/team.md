<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link type="application/atom+xml" rel="alternate" href="https://jekyllrb.com/feed.xml" title="Jekyll • Simple, blog-aware, static sites" />
  <link type="application/atom+xml" rel="alternate" href="/feed/release.xml" title="Jekyll releases posts" />
  <link rel="alternate" type="application/atom+xml" title="Recent commits to Jekyll’s master branch" href="https://github.com/jekyll/jekyll/commits/master.atom">
  <link rel="preload" href="/fonts/lato-v14-latin-300.woff2" as="font" type="font/woff2" crossorigin />
  <link rel="preload" href="/fonts/lato-v14-latin-700.woff2" as="font" type="font/woff2" crossorigin />
  <link rel="preload" href="/css/screen.css" as="style">
  <link rel="stylesheet" href="/css/screen.css">
  <link rel="icon" type="image/x-icon" href="/favicon.ico">
  <!-- Begin Jekyll SEO tag v2.8.0 -->
<title>Jekyll • Simple, blog-aware, static sites | Transform your plain text into static websites and blogs</title>
<meta name="generator" content="Jekyll v4.3.4" />
<meta property="og:title" content="Jekyll • Simple, blog-aware, static sites" />
<meta property="og:locale" content="en_US" />
<meta name="description" content="Transform your plain text into static websites and blogs" />
<meta property="og:description" content="Transform your plain text into static websites and blogs" />
<link rel="canonical" href="https://jekyllrb.com/404.html" />
<meta property="og:url" content="https://jekyllrb.com/404.html" />
<meta property="og:site_name" content="Jekyll • Simple, blog-aware, static sites" />
<meta property="og:image" content="https://jekyllrb.com/img/jekyll-og.png" />
<meta property="og:type" content="website" />
<meta name="twitter:card" content="summary_large_image" />
<meta property="twitter:image" content="https://jekyllrb.com/img/jekyll-og.png" />
<meta property="twitter:title" content="Jekyll • Simple, blog-aware, static sites" />
<meta name="twitter:site" content="@jekyllrb" />
<meta name="google-site-verification" content="onQcXpAvtHBrUI5LlroHNE_FP0b2qvFyPq7VZw36iEY" />
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"WebPage","description":"Transform your plain text into static websites and blogs","headline":"Jekyll • Simple, blog-aware, static sites","image":"https://jekyllrb.com/img/jekyll-og.png","publisher":{"@type":"Organization","logo":{"@type":"ImageObject","url":"https://jekyllrb.com/img/logo-2x.png"}},"url":"https://jekyllrb.com/404.html"}</script>
<!-- End Jekyll SEO tag -->

  <!--[if lt IE 9]>
  <script src="/js/html5shiv.min.js"></script>
  <script src="/js/respond.min.js"></script>
  <![endif]-->
</head>


<body class="wrap">
  <header>
    <div class="grid">
      <div class="unit whole align-center">
        <h1>
          <a href="/">
            <span class="sr-only">Jekyll</span>
            <img src="/img/logo-2x.png" width="249" height="115" alt="Jekyll Logo">
          </a>
        </h1>
      </div>
    </div>
  </header>

  <section class="intro">
  <div class="grid">
    <div class="unit whole align-center">
      <p class="first">Huh. It seems that page is<br/>Hyde-ing...</p>
    </div>
  </div>
</section>

<section class="error">
  <div class="grid">
    <div class="unit whole align-center">
      <p>The resource you requested was not found. Here are some links to help you find your way:</p>
      <nav class="main-nav">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/docs/home/">Documentation</a></li>
          <li><a href="/news/">News</a></li>
          <li><a href="/help/">Help</a></li>
        </ul>
      </nav>
    </div>
  </div>
</section>


  <script>
/* Creates an anchor element with the given ID and link for the permalink*/
const anchorForId = (id) => {
  const anchor = document.createElement("a");
  anchor.className = "header-link";
  anchor.href = `#${id}`;
  anchor.innerHTML = `<span class="sr-only">Permalink</span><i class="fa fa-link" aria-hidden="true"></i>`;
  anchor.title = "Permalink";
  return anchor;
};

/* Finds all headers of the specified level within the given element, and adds a permalink to each header*/
const linkifyAnchors = (level, containingElement) => {
  const headers = Array.from(containingElement.getElementsByTagName(`h${level}`));
  headers.forEach((header) => {
    if (header.id) {
      header.appendChild(anchorForId(header.id));
    }
  });
};

/* Executes the function when the document is ready */
document.onreadystatechange = () => {
  if (document.readyState === "complete") {
    const contentBlock = document.getElementsByClassName("docs")[0]
      ?? document.getElementsByClassName("news")[0];
    if (!contentBlock) { return; }
    for (let level = 1; level <= 6; level++) {
      linkifyAnchors(level, contentBlock);
    }
  }
};
</script>

  <!-- Google Analytics (https://www.google.com/analytics) -->
  <script>
    !function(j,e,k,y,l,L){j.GoogleAnalyticsObject=y,j[y]||(j[y]=function(){
    (j[y].q=j[y].q||[]).push(arguments)}),j[y].l=+new Date,l=e.createElement(k),
    L=e.getElementsByTagName(k)[0],l.src='https://www.google-analytics.com/analytics.js',
    L.parentNode.insertBefore(l,L)}(window,document,'script','ga');

    ga('create', 'UA-50755011-1', 'jekyllrb.com');
    ga('send', 'pageview');
  </script>


</body>
</html>
